from .auth import router as auth_router
from .admin import router as admin_router
from .servers import router as servers_router
from .backups import router as backups_router
from .mods import router as mods_router
from .config_editor import router as config_editor_router
from .system import router as system_router
from .steam import router as steam_router

__all__ = [
    "auth_router",
    "admin_router",
    "servers_router",
    "backups_router",
    "mods_router",
    "config_editor_router",
    "system_router",
    "steam_router",
]
