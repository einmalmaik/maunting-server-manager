import { create } from 'zustand'
import { api } from '@/api/client'
import type { User } from '@/types'

interface AuthState {
  user: User | null
  isLoading: boolean
  isAuthenticated: boolean
  setUser: (user: User | null) => void
  setAuthenticated: (val: boolean) => void
  logout: () => Promise<void>
  checkAuth: () => Promise<void>
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  isLoading: true,
  isAuthenticated: false,

  setUser: (user) => set({ user }),

  setAuthenticated: (val) => set({ isAuthenticated: val }),

  logout: async () => {
    try {
      await api('/auth/logout', { method: 'POST' })
    } catch {
      // Ignorieren: Backend hat Cookies geloescht, Client-State wird hier bereinigt
    }
    set({ user: null, isAuthenticated: false, isLoading: false })
  },

  checkAuth: async () => {
    set({ isLoading: true })
    try {
      const user = await api<User>('/auth/me')
      set({ user, isAuthenticated: true, isLoading: false })
    } catch {
      set({ user: null, isAuthenticated: false, isLoading: false })
    }
  },
}))
